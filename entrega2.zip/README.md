Mejoras respecto la primera entrega
------------------------------------

Ahora los slides estan paginados, y el color de los puntitos va con la estetica.

La foto del home ahora no esta deformada (es otra), y tiene algo de relleno,
sin funcionalidad real, ademas de tener la tabbar transparente.

En la pagina de lista, el color de los botones remove y edit han sido cambiados a unos que encajan mejor, y agrandados
y ajustados de forma que al deslizar, encajen con la linea blanca que separa las canciones, no asi con la de abajo, porque no se
ha podido hacer.

Por como se porta ionic a veces, te adjunto imagenes de como debria verse la aplicacion normalmente en "como deberia verse".
